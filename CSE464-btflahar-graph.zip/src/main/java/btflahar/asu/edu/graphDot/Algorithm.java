package btflahar.asu.edu.graphDot;

public enum Algorithm {
    BFS,
    DFS
}
